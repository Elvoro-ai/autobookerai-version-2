// @ts-check
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    // Ensure App Router is enabled (Next 13+)
    optimizePackageImports: [],
  },
};

module.exports = nextConfig;
