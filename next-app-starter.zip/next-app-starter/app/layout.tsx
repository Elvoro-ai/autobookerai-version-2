export const metadata = {
  title: "Next.js App Router Starter",
  description: "Minimal app/ structure so Netlify/Next.js build can run.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Helvetica Neue, Arial, sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
