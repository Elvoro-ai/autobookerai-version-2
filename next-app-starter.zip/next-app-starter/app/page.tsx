export default function Page() {
  return (
    <main style={{ padding: 32 }}>
      <h1>It works 🎉</h1>
      <p>
        This is a minimal <code>app/</code> directory so <strong>next build</strong> doesn't fail.
      </p>
      <p>
        Replace this with your real application code.
      </p>
    </main>
  );
}
