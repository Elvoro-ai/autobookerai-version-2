# Minimal `app/` directory for Next.js on Netlify

This starter gives you the bare minimum to satisfy Next.js' requirement for either a `pages/` or `app/` directory.

## How to use

1. Download this zip and extract it at the **root of your Next.js repo**.
   - It will create an `app/` folder with two files: `layout.tsx` and `page.tsx`.
   - It also includes a sample `netlify.toml` and `next.config.js` (optional if you already have your own).
2. Commit and push.
3. In Netlify:
   - **Build command**: `npm run build`
   - **Publish directory**: leave empty (the Next.js plugin will handle output) or `.next` if you prefer manual.
   - Make sure the **Base directory** points to the repo root that contains this `app/` directory. If your app lives in a subfolder (e.g. `web/`), set Base directory to that folder.
4. Re‑deploy.

## Troubleshooting checklist

- If your real app is in a subfolder (e.g. `apps/web`), either move it to the repo root **or** set Netlify **Base directory** accordingly.
- Ensure your `package.json` contains scripts:

```json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  }
}
```

- Install deps: `npm i next react react-dom` (or `pnpm add` / `yarn add`).
- Enable the official plugin in Netlify: `@netlify/plugin-nextjs` (already set in `netlify.toml`).

## Notes

- If you already have a `pages/` router, you don't need this. Remove `app/` and keep your `pages/` folder instead.
- The `app/` and `pages/` routers can technically coexist, but avoid route conflicts.
