import { Worker } from "bullmq";
import IORedis from "ioredis";
import { db } from "@/lib/db";
import { scoreLead } from "@/lib/agents";

const connection = new IORedis(process.env.REDIS_URL!, { maxRetriesPerRequest: null });

new Worker("lead-scoring", async job => {
  const { leadId } = job.data as { leadId: string };
  const lead = await db.lead.findUnique({ where: { id: leadId } });
  if (!lead) return;

  const result = await scoreLead({
    name: lead.name ?? undefined,
    locale: lead.locale ?? undefined,
    lastMessage: lead.lastMessage ?? ""
  });

  await db.lead.update({
    where: { id: leadId },
    data: {
      score: result.score,
      scoreReason: result.reasons.join("; "),
      status: result.nextAction === "offer_booking" ? "qualified" : "new"
    }
  });
}, { connection });

console.log("Lead-scoring worker started.");
