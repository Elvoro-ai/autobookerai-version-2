import OpenAI from "openai";
import { ScoringSchema, scoringUserTemplate, SYSTEM_PROMPT, type Scoring } from "@/lib/prompts";
import { z } from "zod";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function scoreLead(input: {
  name?: string;
  locale?: string;
  lastMessage: string;
  context?: Record<string, any>;
}): Promise<Scoring> {
  const user = scoringUserTemplate(input);
  const res = await client.chat.completions.create({
    model: "gpt-4o-mini",
    temperature: 0.2,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: user }
    ],
    response_format: { type: "json_object" }
  });

  const raw = res.choices[0]?.message?.content ?? "{}";
  const parsed = ScoringSchema.safeParse(JSON.parse(raw));
  if (!parsed.success) {
    throw new Error("Invalid scoring JSON: " + parsed.error.message);
  }
  return parsed.data;
}
