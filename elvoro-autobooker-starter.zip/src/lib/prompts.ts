import { z } from "zod";

export const ScoringSchema = z.object({
  score: z.number().min(0).max(100),
  intent: z.enum(["low", "medium", "high"]),
  fit: z.enum(["poor", "ok", "good"]),
  reasons: z.array(z.string()).min(1),
  nextAction: z.enum(["nurture", "ask_clarifying", "offer_booking"]),
  suggestedReply: z.string().min(1)
});
export type Scoring = z.infer<typeof ScoringSchema>;

export const SYSTEM_PROMPT = `
You are "Elvoro Concierge", a multilingual AI that qualifies inbound leads for coaches/agencies.
Goals:
- Extract intent, fit, objections, urgency.
- If high intent & good fit, offer a booking link.
- Be respectful, GDPR-aware, and concise.
- Always produce JSON following the provided schema.
Language: mirror the user's language; default to French (fr-FR).
`;

export const scoringUserTemplate = (lead: {
  name?: string;
  locale?: string;
  lastMessage?: string;
  context?: Record<string, any>;
}) => `
Lead profile:
- name: ${lead.name || "unknown"}
- locale: ${lead.locale || "fr-FR"}
- lastMessage: ${lead.lastMessage || ""}
- context: ${JSON.stringify(lead.context || {}, null, 2)}

Return ONLY a JSON strictly matching the schema.
`;
