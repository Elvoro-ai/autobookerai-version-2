# Elvoro | Autobooker AI — Starter (Netlify-ready)

A minimal, production-grade skeleton for a multi-tenant lead intake + scoring + booking flow using Next.js App Router + Prisma + BullMQ + OpenAI.

## What you get
- **Multi-tenant data model** (Tenant, User, Lead, Interaction, Booking)
- **Ingest Webhook** `/api/ingest` (validates HMAC-like secret, stores lead + conversation)
- **Lead Scoring Job** (BullMQ) using structured AI output via Zod schema
- **Agent Prompts** centralized in `src/lib/prompts.ts`
- **Booking API** `/api/book` (proxy to your provider: Cal.com/Calendly/etc.)
- **Netlify compatible** (`@netlify/plugin-nextjs`)

## Quick start
1. Clone / unzip in your repo.
2. Create `.env` from `.env.example`. Fill credentials (Postgres + Redis + OpenAI + provider).
3. Install & generate:
   ```bash
   npm i
   npm run prisma:generate
   ```
4. Run locally:
   ```bash
   npm run dev
   # In another terminal, start worker
   npm run jobs:dev
   ```
5. Deploy to **Netlify**:
   - Set build command: `npm run build`
   - Add environment variables from `.env`
   - Install the plugin automatically from `netlify.toml`

## Notes
- This is a secure baseline. Add rate limiting, SSO, audit logs, consent capture.
- For pgvector/RAG, extend Prisma schema and use a vector extension (optional).
