export default function Marketing() {
  return (
    <section className="p-10 text-center">
      <h2 className="text-4xl font-semibold">Convertissez 2x plus de leads avec l'IA</h2>
      <p className="mt-3">Multi-canal, RGPD, orchestré par des agents spécialisés. Déployable sur Netlify.</p>
    </section>
  );
}
