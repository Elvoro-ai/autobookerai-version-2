import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { scoringQueue } from "@/jobs/queue";

function verifySecret(req: NextRequest) {
  const secret = req.headers.get("x-webhook-secret");
  return secret && secret === process.env.INGEST_WEBHOOK_SECRET;
}

export async function POST(req: NextRequest) {
  if (!verifySecret(req)) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }
  const body = await req.json();
  const {
    tenantSlug = process.env.DEFAULT_TENANT || "demo",
    source = "web",
    externalId,
    name,
    email,
    phone,
    message,
    tags = []
  } = body;

  const tenant = await db.tenant.upsert({
    where: { slug: tenantSlug },
    create: { slug: tenantSlug, name: tenantSlug.toUpperCase() },
    update: {}
  });

  const lead = await db.lead.create({
    data: {
      tenantId: tenant.id,
      source,
      externalId,
      name,
      email,
      phone,
      lastMessage: message,
      tags
    }
  });

  await db.interaction.create({
    data: {
      leadId: lead.id,
      channel: source,
      direction: "in",
      content: message || ""
    }
  });

  await scoringQueue.add("score", { leadId: lead.id }, { removeOnComplete: 100, removeOnFail: 100 });

  return NextResponse.json({ ok: true, leadId: lead.id });
}
