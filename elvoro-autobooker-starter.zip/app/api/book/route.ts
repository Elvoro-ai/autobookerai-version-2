import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { leadId, slotStart, slotEnd } = await req.json();

  // Example proxy to your booking provider (Cal.com/Calendly/etc.).
  // Replace with your real call and auth.
  const resp = await fetch(`${process.env.BOOKING_BASE_URL}/bookings`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${process.env.BOOKING_API_KEY}`
    },
    body: JSON.stringify({ leadId, slotStart, slotEnd })
  });

  if (!resp.ok) {
    return NextResponse.json({ ok: false, error: "Booking failed" }, { status: 500 });
  }
  const data = await resp.json();
  return NextResponse.json({ ok: true, booking: data });
}
