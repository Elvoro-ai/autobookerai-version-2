export default function Page() {
  return (
    <main className="p-8 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold">Elvoro | Autobooker AI — Starter</h1>
      <p className="mt-4">This minimal app is Netlify-ready and includes an ingest webhook, a scoring worker, and a booking proxy.</p>
      <ul className="list-disc pl-6 mt-4">
        <li>POST <code>/api/ingest</code> to capture leads</li>
        <li>Worker processes <code>lead-scoring</code> jobs</li>
        <li>POST <code>/api/book</code> to schedule calls</li>
      </ul>
    </main>
  );
}
