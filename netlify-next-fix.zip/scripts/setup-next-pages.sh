
#!/usr/bin/env bash
set -euo pipefail

# Crée pages/ s'il n'existe pas et ajoute une page d'accueil minimale
mkdir -p pages

INDEX_TSX_PATH="pages/index.tsx"
if [ ! -f "$INDEX_TSX_PATH" ]; then
  cat > "$INDEX_TSX_PATH" <<'EOF'
import Head from 'next/head'

export default function Home() {
  return (
    <div style={{ padding: 24, fontFamily: 'ui-sans-serif, system-ui' }}>
      <Head>
        <title>Autobooker AI — Netlify OK</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <h1>✅ Next.js trouvé : déploiement Netlify prêt</h1>
      <p>Cette page minimale prouve que le répertoire <code>pages/</code> est bien détecté.</p>
      <ul>
        <li>Fichier: <code>pages/index.tsx</code></li>
        <li>Build: <code>next build</code></li>
        <li>Runtime: <code>next start</code></li>
      </ul>
    </div>
  )
}
EOF
  echo "✔ Créé pages/index.tsx"
else
  echo "• pages/index.tsx existe déjà (ok)"
fi

# Ajoute un squelette minimal de scripts si package.json existe et que 'build' manque
if [ -f package.json ]; then
  if ! grep -q '"build"' package.json; then
    echo "• Ajout de scripts npm (dev/build/start) dans package.json"
    node - <<'EOF'
const fs = require('fs');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
pkg.scripts = Object.assign({ dev: "next dev", build: "next build", start: "next start" }, pkg.scripts || {});
fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2) + "\n");
EOF
  else
    echo "• Script 'build' déjà présent (ok)"
  fi
else
  echo "⚠️  package.json introuvable à la racine — ajoutez-le avant le build."
fi

# Ajoute netlify.toml si absent
if [ ! -f netlify.toml ]; then
  cat > netlify.toml <<'EOF'
[build]
  command = "npm run build"
  publish = ".next"
  environment = { NEXT_TELEMETRY_DISABLED = "1" }

[[plugins]]
  package = "@netlify/plugin-nextjs"
EOF
  echo "✔ Créé netlify.toml"
else
  echo "• netlify.toml existe déjà (ok)"
fi

echo "✅ Setup terminé."
