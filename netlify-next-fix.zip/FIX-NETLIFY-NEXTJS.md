
# Correctif Netlify × Next.js — Absence de `pages` / `app`

**Contexte (logs Netlify)**
```
Error: Couldn't find any `pages` or `app` directory. Please create one under the project root
Context: deploy-preview
Build command from Netlify app
Exit code: 2
```
Node: v22.21.0 (dans vos logs)

---

## 🎯 Objectif
Fournir un **exemple minimal fonctionnel** pour:
- créer `pages/` (ou vérifier son existence),
- pousser une page d’accueil par défaut,
- configurer Netlify pour Next.js,
- déclencher un nouveau build.

> Si vous utilisez l’App Router (`app/`), remplacez simplement `pages/` par `app/` avec un `app/page.tsx`. Ce paquet fournit l’option `pages/` prête à l’emploi.

---

## 📁 Fichiers fournis

- `pages/index.tsx` — Page Next.js minimale (route `/`).
- `netlify.toml` — Configuration Netlify recommandée pour Next.js.
- `scripts/setup-next-pages.sh` — Script idempotent qui crée `pages/` si absent et ajoute une page d’accueil.
- `next.config.mjs` — Config Next par défaut (optionnelle).

---

## 🚀 Procédure rapide (copier/coller)

1) **Téléchargez ce paquet** puis **décompressez-le** à la racine de votre projet Next.js (même niveau que `package.json`).  
2) Exécutez le script de setup :
```bash
chmod +x scripts/setup-next-pages.sh
./scripts/setup-next-pages.sh
```
3) **Vérifiez votre `package.json`** : il doit contenir au moins
```json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  }
}
```
> Si la clé `"build"` est manquante, ajoutez-la puis `git add`/`commit`.

4) **Ajoutez & poussez** sur votre branche GitHub (ex: `Elvoro-ai-patch-1`) :
```bash
git add -A
git commit -m "fix: add pages/ + netlify config for Next.js"
git push
```
5) **Relancez le build Netlify** (il devrait se déclencher automatiquement à chaque push).

---

## 🔧 Détails & variantes

### A. Vous utilisez **App Router** (Next 13+)
- Au lieu de `pages/index.tsx`, créez :
```
app/page.tsx
```
avec :
```tsx
export default function Home() {
  return <main style={{padding: 24}}><h1>It works on Netlify ✅</h1></main>
}
```
- Conservez `netlify.toml` et les scripts `package.json` ci‑dessus.

### B. Dépannage courant
- **"Couldn't find any `pages` or `app` directory"** → assurez-vous que `pages/` *ou* `app/` est **à la racine** du dépôt (pas dans un sous-dossier).
- **"npm ERR! Missing script: build"** → ajoutez la clé `"build": "next build"` dans `package.json`.
- **Monorepo / sous-dossier** → si votre app n’est pas à la racine, indiquez le chemin dans Netlify → *Site settings* → *Build & deploy* → *Base directory* (ex: `apps/web`).

### C. Node/Plugin
- Netlify détecte Next.js et installe `@netlify/plugin-nextjs` automatiquement. Le `netlify.toml` fourni l’active explicitement.
- Si vous rencontrez des soucis de version Node, épinglez‑la dans Netlify (*Environment → NODE_VERSION*) ou via `.nvmrc`.

---

## ✅ Résultat attendu
Après push, Netlify doit construire sans l’erreur et déployer un aperçu fonctionnel avec la page d’accueil minimale.

Bon déploiement !
