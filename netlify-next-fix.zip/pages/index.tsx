
import Head from 'next/head'

export default function Home() {
  return (
    <div style={{ padding: 24, fontFamily: 'ui-sans-serif, system-ui' }}>
      <Head>
        <title>Autobooker AI — Netlify OK</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <h1>✅ Next.js trouvé : déploiement Netlify prêt</h1>
      <p>Cette page minimale prouve que le répertoire <code>pages/</code> est bien détecté.</p>
      <ul>
        <li>Fichier: <code>pages/index.tsx</code></li>
        <li>Build: <code>next build</code></li>
        <li>Runtime: <code>next start</code></li>
      </ul>
    </div>
  )
}
