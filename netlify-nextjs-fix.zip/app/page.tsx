export default function Home() {
  return (
    <main style={{ display: "grid", placeItems: "center", minHeight: "100dvh", padding: 24 }}>
      <div style={{ maxWidth: 720, textAlign: "center" }}>
        <h1 style={{ fontSize: 36, lineHeight: 1.2, marginBottom: 8 }}>✅ Netlify x Next.js is working</h1>
        <p style={{ opacity: 0.8 }}>
          This minimal <strong>app/</strong> router setup ensures Netlify finds a valid Next.js app.
        </p>
        <ol style={{ textAlign: "left", marginTop: 24 }}>
          <li>Update this page with your SaaS app.</li>
          <li>Commit and push to <code>main</code>.</li>
          <li>Netlify will build with Node 20 and the Next.js plugin.</li>
        </ol>
      </div>
    </main>
  );
}