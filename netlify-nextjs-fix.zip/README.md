# Netlify → Next.js Fix (App Router)

This folder is a drop-in, minimal **Next.js** project configured for **Netlify**.
It ensures Netlify finds a valid Next.js app (the error you saw: _"Couldn't find any `pages` or `app` directory"_).

## What it includes
- `app/` router with a minimal `page.tsx` and `layout.tsx`
- `netlify.toml` to:
  - pin Node to **20** (avoids Node 22 build surprises)
  - enable the official **@netlify/plugin-nextjs**
- `package.json` scripts and dependencies
- TypeScript config and basic `.gitignore`

## How to use (fastest path)
1. **Copy the files** from this folder into the root of your repo (or compare/merge with your existing project).
2. Ensure your app code lives under **`app/`** (or alternatively create a `pages/` folder).
3. Commit and push to `main`.
4. In Netlify site settings (Deploys → Build settings), set:
   - **Base directory**: *(leave empty / repo root)*
   - **Build command**: `npm run build`
   - **Publish directory**: `.next`
5. Trigger a new deploy.

> If you already had a Next.js app but in a subfolder, either move it to the repo root or set the **Base directory** in Netlify to that subfolder.

## Local smoke test
```bash
npm i
npm run typecheck
npm run build
npm run start
```

## GitHub Actions (optional)
A simple CI workflow is included to run typecheck & build on push.