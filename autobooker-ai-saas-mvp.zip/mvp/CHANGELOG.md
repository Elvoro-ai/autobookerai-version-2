# Changelog

## 0.2.0 (2025-10-13)

### Added

- **lib/error.ts**: Fournit une fonction `errorResponse` pour normaliser les objets d’erreur retournés par toutes les routes API. Les erreurs suivent désormais la forme `{ error: { code, message } }`.  
- **Consent**: Nouveau modèle Prisma (`Consent`) et énumération `ConsentType` pour stocker les consentements e‑mail et SMS conformément au RGPD.
- **lib/ai.ts**: Implémentation d’un cache Redis et de heuristiques pour `suggestBestSlots`, `smartReminderCopy` et `noShowRisk`. Les appels LLM sont débrayables et protégés par l’environnement.
- **.env.example**: Ajout de variables pour Calendly, Twilio et Gmail.  
- **CHANGELOG.md**: Ce fichier, afin de documenter les évolutions du code.

### Changed

- **app/api/appointments/route.ts**, **app/api/availability/route.ts**, **app/api/notify/send/route.ts**, **app/api/cron/reminders/route.ts**: Remplacé les réponses d’erreur disparates par des appels à `errorResponse`. Validation améliorée avec Zod et messages d’erreur plus explicites.
- **README.md**: Ajout d’une documentation sur le format des erreurs, des codes d’erreur, de la procédure d’incident et des tests cURL supplémentaires.

### Removed

- N/A

---

## 0.1.0 (2025-10-13)

Version initiale générée avec Lovable et enrichie pour la performance et la CI.