import { NextRequest, NextResponse } from 'next/server';

/**
 * A simple in-memory rate limiter. For production use a distributed store
 * such as Redis or Upstash. Limit is per IP per minute.
 */
const RATE_LIMIT = 100;
const WINDOW_MS = 60 * 1000;
const hits: Record<string, { count: number; expires: number }> = {};

export function rateLimit(handler: (req: NextRequest) => Promise<Response>) {
  return async (req: NextRequest) => {
    const ip = (req.headers.get('x-forwarded-for') || '')
      .split(',')[0]
      .trim();
    const now = Date.now();
    const record = hits[ip] || { count: 0, expires: now + WINDOW_MS };
    if (now > record.expires) {
      record.count = 0;
      record.expires = now + WINDOW_MS;
    }
    record.count++;
    hits[ip] = record;
    if (record.count > RATE_LIMIT) {
      return new Response('Too many requests', { status: 429 });
    }
    return handler(req);
  };
}