import { z } from 'zod';

export const availabilitySchema = z.object({
  start: z.string().refine((val) => !isNaN(Date.parse(val)), 'Invalid date'),
  end: z.string().refine((val) => !isNaN(Date.parse(val)), 'Invalid date'),
});

export const appointmentSchema = z.object({
  coachId: z.string(),
  start: z.string().refine((val) => !isNaN(Date.parse(val)), 'Invalid date'),
  end: z.string().refine((val) => !isNaN(Date.parse(val)), 'Invalid date'),
  status: z.enum(['SCHEDULED', 'RESCHEDULED', 'CANCELLED']).optional(),
  noShowRisk: z.number().min(0).max(1).optional(),
  clientEmail: z.string().email(),
});