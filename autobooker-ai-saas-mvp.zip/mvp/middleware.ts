import { NextRequest, NextResponse } from 'next/server';
import { Ratelimit } from '@upstash/ratelimit';
import { redis } from '@/lib/redis';

/**
 * Global rate limiter using Upstash Redis. Limits each IP to 100 requests per minute.
 */
const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(100, '1 m'),
});

export async function middleware(req: NextRequest) {
  if (!req.nextUrl.pathname.startsWith('/api')) {
    return NextResponse.next();
  }
  const ip =
    (req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip') ||
      '127.0.0.1');
  const { success } = await ratelimit.limit(ip);
  if (!success) {
    return new NextResponse('Too many requests', { status: 429 });
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/api/:path*'],
};