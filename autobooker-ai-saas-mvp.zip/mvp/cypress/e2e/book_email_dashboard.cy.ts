describe('Booking flow', () => {
  it('allows a user to book a session and see it on the dashboard', () => {
    // Visit landing page
    cy.visit('/');
    // Click on CTA
    cy.contains('Commencer').click();
    // We are now on demo coach booking page
    cy.url().should('include', '/book/');
    // Wait for available slots
    cy.get('button').contains(':').first().click();
    // Fill email
    cy.get('input[type="email"]').type('test@example.com');
    // Confirm booking
    cy.contains('Confirmer').click();
    // Redirect to dashboard
    cy.url().should('include', '/dashboard');
    // Appointment appears in list
    cy.contains('test@example.com');
  });
});