// This file is processed and loaded automatically before your test files.
// Put your global configuration and behavior that modifies Cypress here.

// import commands.js using ES2015 syntax:
// import './commands';

// Alternatively you can use CommonJS syntax:
// require('./commands');