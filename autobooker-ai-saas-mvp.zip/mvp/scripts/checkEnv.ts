import fs from 'fs';
import path from 'path';

// Simple script to ensure that all variables from .env.example are present in .env.
const root = process.cwd();
const exampleEnv = fs.readFileSync(path.join(root, '.env.example'), 'utf8');
const env = fs.readFileSync(path.join(root, '.env'), 'utf8');
const exampleVars = exampleEnv
  .split('\n')
  .filter((line) => line.trim() && !line.trim().startsWith('#'))
  .map((line) => line.split('=')[0]);
const envVars = env
  .split('\n')
  .filter((line) => line.trim() && !line.trim().startsWith('#'))
  .map((line) => line.split('=')[0]);
const missing = exampleVars.filter((v) => !envVars.includes(v));
if (missing.length > 0) {
  console.error('Missing environment variables:', missing.join(', '));
  process.exit(1);
}
console.log('All required environment variables are present.');