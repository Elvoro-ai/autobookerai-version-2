/**
 * Simple logger. In production you could replace this with a real logging
 * library like pino. For now it just proxies to console methods and
 * ensures that logging is disabled in test environments.
 */
const isTest = process.env.NODE_ENV === 'test';
export const logger = {
  info: (...args: any[]) => {
    if (!isTest) console.info(...args);
  },
  warn: (...args: any[]) => {
    if (!isTest) console.warn(...args);
  },
  error: (...args: any[]) => {
    if (!isTest) console.error(...args);
  },
};