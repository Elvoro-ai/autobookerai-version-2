import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY || '');

/**
 * Send an email using Resend. You must set RESEND_API_KEY and RESEND_FROM
 * environment variables. The `html` parameter should contain the full
 * HTML body of the email.
 */
export async function sendEmail(to: string, subject: string, html: string) {
  if (!process.env.RESEND_FROM) throw new Error('Missing RESEND_FROM env var');
  await resend.emails.send({
    from: process.env.RESEND_FROM,
    to,
    subject,
    html,
  });
}