import { redis } from './redis';

/**
 * Suggest the best three time slots from a coach's availability based on
 * optional user preferences. This function should call an LLM (OpenAI/Mistral)
 * and cache results in Redis. If the LLM is unavailable, fall back to a
 * simple heuristic that picks the first three available slots.
 */
export async function suggestBestSlots(
  availability: Array<{ start: Date; end: Date }>,
  preferences?: any
): Promise<Array<{ start: Date; end: Date }>> {
  /**
   * Suggest the best three time slots from a coach's availability using an
   * LLM if possible. The result is cached in Redis to reduce LLM usage and
   * bound costs. The cache key is derived from the availability and
   * preference hash. If the LLM call fails or no API key is configured,
   * fall back to picking the earliest three slots.
   */
  try {
    const key = `slots:${availability.length}:${JSON.stringify(preferences ?? {})}`;
    // Check cache first
    const cached = await redis.get(key);
    if (cached) {
      return JSON.parse(cached);
    }
    // Only attempt LLM call if API keys are configured
    if (process.env.OPENAI_API_KEY || process.env.MISTRAL_API_KEY) {
      // Build prompt for LLM (omitted here to avoid leaking API usage)
      // const prompt = ...;
      // TODO: call your preferred LLM provider here using fetch() and
      // process.env.OPENAI_API_KEY or MISTRAL_API_KEY. Ensure temperature
      // and context are constrained to bound cost. Parse the JSON response.
      // Example (pseudo‑code):
      // const response = await fetch('https://api.openai.com/v1/chat/completions', {...});
      // const data = await response.json();
      // const slots = JSON.parse(data.choices[0].message.content);
      // For this template we skip the call and use fallback.
    }
    // Fallback heuristic: sort by start time and pick first three
    const sorted = [...availability].sort((a, b) => a.start.getTime() - b.start.getTime());
    const slots = sorted.slice(0, 3);
    // Cache result with TTL (1 hour)
    await redis.set(key, JSON.stringify(slots), { ex: 3600 });
    return slots;
  } catch (err) {
    // In case of any error, gracefully fall back
    const sorted = [...availability].sort((a, b) => a.start.getTime() - b.start.getTime());
    return sorted.slice(0, 3);
  }
}

/**
 * Generate a personalized reminder copy for an appointment. Use an LLM when
 * available, otherwise fall back to a static template.
 */
export function smartReminderCopy({
  coachName,
  clientName,
  dateISO,
  location,
}: {
  coachName: string;
  clientName: string;
  dateISO: string;
  location?: string;
}): string {
  /**
   * Generate a personalized reminder message. When a language model is
   * configured (via OPENAI_API_KEY or MISTRAL_API_KEY) this function can
   * construct a prompt and call the LLM to create a unique, friendly
   * message. To control costs we avoid using a high temperature and keep
   * context minimal. If the call fails or no API key is set, we fall back
   * to a simple template.
   */
  // TODO: implement actual LLM call similar to suggestBestSlots. For now
  // use a deterministic template.
  const date = new Date(dateISO).toLocaleString('fr-FR', {
    dateStyle: 'full',
    timeStyle: 'short',
  });
  return `Bonjour ${clientName}, ceci est un rappel pour votre séance avec ${coachName} le ${date}${
    location ? ` à ${location}` : ''
  }.`;
}

/**
 * Predict the probability that a client will not show up to an appointment.
 * Returns a value between 0 and 1. Use an LLM or heuristic.
 */
export async function noShowRisk(appointment: any): Promise<number> {
  /**
   * Predict the probability that a client will not show up. An LLM can be
   * used here with a small prompt containing appointment details. To
   * minimize cost, prune unnecessary context and use a low temperature. If
   * the LLM is unavailable, use a heuristic based on how far in the
   * future the appointment is and the client's history (not yet
   * implemented). The output should be between 0 and 1.
   */
  try {
    if (process.env.OPENAI_API_KEY || process.env.MISTRAL_API_KEY) {
      // TODO: call LLM to compute risk. Example (pseudo‑code):
      // const prompt = `Predict no‑show risk for appointment: ${JSON.stringify(appointment)}`;
      // const response = await fetch(...);
      // const score = parseFloat(response.choices[0].message.content);
      // return Math.min(Math.max(score, 0), 1);
    }
    // Simple heuristic: further future appointments have slightly higher risk
    const now = Date.now();
    const start = new Date(appointment.start).getTime();
    const diffHours = (start - now) / (1000 * 60 * 60);
    // risk increases linearly up to 0.4 when 72h away
    const risk = Math.min(Math.max(diffHours / 72, 0), 0.4);
    return Number(risk.toFixed(2));
  } catch {
    return 0.1;
  }
}