import Stripe from 'stripe';

/**
 * Instantiate the Stripe client.
 * The secret key must be provided via the environment variable STRIPE_SECRET_KEY.
 */
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2024-04-10',
});

export type CheckoutPlan = 'BASIC' | 'PRO';

/**
 * Create a checkout session for a given plan.
 *
 * @param userId The ID of the user subscribing
 * @param plan The plan (BASIC or PRO)
 * @param successUrl URL to redirect after successful payment
 * @param cancelUrl URL to redirect if user cancels
 */
export async function createCheckoutSession({
  userId,
  plan,
  successUrl,
  cancelUrl,
}: {
  userId: string;
  plan: CheckoutPlan;
  successUrl: string;
  cancelUrl: string;
}) {
  // Define pricing IDs for your Stripe products
  const priceId = plan === 'PRO' ? process.env.STRIPE_PRICE_PRO : process.env.STRIPE_PRICE_BASIC;
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: {
      userId,
      plan,
    },
  });
  return session;
}