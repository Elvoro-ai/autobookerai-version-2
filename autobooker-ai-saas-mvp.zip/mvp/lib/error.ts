import { NextResponse } from 'next/server';

/**
 * Build a JSON error response with a standardized shape. All API endpoints
 * should return errors using this helper to ensure consistent handling on
 * the frontend. The returned object will be of the form
 * `{ error: { code: string, message: string } }` with the provided HTTP
 * status code. See README for a matrix of error codes.
 *
 * @param code A short, machine‑readable error code (e.g. `MISSING_COACH_ID`).
 * @param message A human‑readable explanation of the error.
 * @param status The HTTP status code to return. Defaults to 400.
 */
export function errorResponse(
  code: string,
  message: string,
  status: number = 400,
): ReturnType<typeof NextResponse.json> {
  return NextResponse.json({ error: { code, message } }, { status });
}