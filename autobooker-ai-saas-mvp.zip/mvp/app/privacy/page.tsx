export default function PrivacyPage() {
  return (
    <main className="max-w-4xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Politique de confidentialité</h1>
      <p className="text-gray-600 dark:text-gray-400">
        Cette politique explique comment nous collectons, utilisons et protégeons vos données personnelles. Ajoutez ici votre politique de confidentialité pour respecter le RGPD.
      </p>
    </main>
  );
}