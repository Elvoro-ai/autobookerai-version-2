import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Slot {
  start: string;
  end: string;
}

export default function BookCoachPage({ params }: { params: { coach: string } }) {
  const router = useRouter();
  const { coach } = params;
  const [slots, setSlots] = useState<Slot[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null);
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    async function fetchSlots() {
      setLoading(true);
      try {
        const res = await fetch(`/api/availability?coachId=${coach}`);
        const data = await res.json();
        setSlots(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchSlots();
  }, [coach]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedSlot) return;
    await fetch('/api/appointments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        coachId: coach,
        start: selectedSlot.start,
        end: selectedSlot.end,
        clientEmail: email,
      }),
    });
    router.push('/dashboard');
  }

  return (
    <main className="max-w-3xl mx-auto p-6 space-y-8">
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-4">Réserver avec votre coach</h1>
      <p className="text-center text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-6">
        Choisissez un créneau qui vous convient parmi les disponibilités ci‑dessous et recevez votre confirmation par e‑mail.
      </p>
      <div>
        <h2 className="text-xl font-semibold mb-3">Choisissez un créneau</h2>
        {loading ? (
          // Skeleton loader while slots are fetching
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <li key={i} className="h-16 rounded-lg bg-gray-200 dark:bg-gray-700 animate-pulse"></li>
            ))}
          </ul>
        ) : slots.length === 0 ? (
          <p className="text-gray-500">Aucune disponibilité pour le moment.</p>
        ) : (
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {slots.map((slot) => (
              <li key={slot.start}>
                <button
                  type="button"
                  onClick={() => setSelectedSlot(slot)}
                  className={`w-full px-4 py-3 rounded-lg border transition-colors duration-150 ${
                    selectedSlot?.start === slot.start
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-white dark:bg-gray-800 hover:bg-indigo-50 dark:hover:bg-indigo-900'
                  }`}
                >
                  <span className="block font-medium">
                    {new Date(slot.start).toLocaleDateString('fr-FR')} 
                  </span>
                  <span className="block text-sm text-gray-500 dark:text-gray-400">
                    {new Date(slot.start).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} — {new Date(slot.end).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      {selectedSlot && (
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-2">Vos informations</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-1">
                Votre e‑mail
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="mt-1 p-2 border rounded-md w-full dark:bg-gray-800 dark:border-gray-700"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              Confirmer le rendez‑vous
            </button>
          </form>
        </div>
      )}
    </main>
  );
}