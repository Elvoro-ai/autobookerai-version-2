import { useEffect, useState } from 'react';

interface Appointment {
  id: string;
  start: string;
  end: string;
  status: string;
  clientEmail: string;
}


export default function DashboardPage() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function fetchAppointments() {
      try {
        const res = await fetch('/api/appointments');
        const data = await res.json();
        setAppointments(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchAppointments();
  }, []);

  return (
    <main className="max-w-4xl mx-auto p-6 space-y-8">
      <header className="text-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">Votre tableau de bord</h1>
        <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Retrouvez ici l’historique de vos rendez‑vous et les prochaines séances programmées. Gérez votre planning en toute simplicité.
        </p>
      </header>
      <section className="bg-white dark:bg-gray-900 shadow rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Mes rendez‑vous</h2>
        {loading ? (
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {[1, 2, 3].map((i) => (
              <li key={i} className="py-4 flex justify-between items-center animate-pulse">
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
                </div>
                <div className="h-5 w-20 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
              </li>
            ))}
          </ul>
        ) : appointments.length === 0 ? (
          <p className="text-gray-500">Aucun rendez‑vous pour l’instant.</p>
        ) : (
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {appointments.map((appt) => (
              <li key={appt.id} className="py-4 flex justify-between items-center">
                <div>
                  <p className="font-medium">
                    {new Date(appt.start).toLocaleDateString('fr-FR')} 
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {new Date(appt.start).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} – {new Date(appt.end).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{appt.clientEmail}</p>
                </div>
                <span
                  className={`text-sm capitalize px-2 py-1 rounded-full ${
                    appt.status === 'CANCELLED'
                      ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300'
                      : appt.status === 'RESCHEDULED'
                      ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300'
                      : 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300'
                  }`}
                >
                  {appt.status.toLowerCase()}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}