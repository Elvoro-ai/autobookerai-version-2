export default function LegalPage() {
  return (
    <main className="max-w-4xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Mentions légales</h1>
      <p className="text-gray-600 dark:text-gray-400">
        Cette page fournit les informations légales relatives à l’application AutoBooker AI. Veuillez compléter ce contenu avec vos informations de société, coordonnées et mentions requises par la loi.
      </p>
    </main>
  );
}