import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'AutoBooker AI',
  description: 'SaaS de gestion de rendez‑vous alimenté par l’IA',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className="min-h-full">
      <body className={inter.className + ' bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100'}>
        {children}
      </body>
    </html>
  );
}