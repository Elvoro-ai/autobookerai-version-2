export default function TermsPage() {
  return (
    <main className="max-w-4xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Conditions générales d’utilisation</h1>
      <p className="text-gray-600 dark:text-gray-400">
        Ces conditions décrivent les règles et obligations liées à l’utilisation de notre service. Veuillez compléter ce texte pour définir vos conditions générales.
      </p>
    </main>
  );
}