export default function AdminPage() {
  return (
    <main className="max-w-3xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Administration</h1>
      <p className="text-gray-600 dark:text-gray-400">
        Cette section est réservée aux administrateurs pour gérer les coaches, les quotas et les rôles des utilisateurs.
      </p>
      {/* TODO: Add management UI for coaches, quotas and roles */}
    </main>
  );
}