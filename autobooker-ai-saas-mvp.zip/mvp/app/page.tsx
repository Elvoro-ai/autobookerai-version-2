/**
 * Landing page pour AutoBooker AI. Cette version offre un design premium
 * avec un hero accrocheur, une section de fonctionnalités et un appel à
 * l’action. Les classes Tailwind utilisent des dégradés, une grille
 * responsive et des micro‑interactions (hover/transition) pour rendre
 * l’interface attractive et accessible (mode sombre inclus).
 */

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-slate-50 to-slate-100 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950">
      {/* Hero Section */}
      <section className="flex flex-col items-center justify-center px-6 py-24 text-center">
        <h1 className="text-6xl font-extrabold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-500">
          AutoBooker&nbsp;AI
        </h1>
        <p className="max-w-2xl text-xl md:text-2xl text-gray-700 dark:text-gray-300 mb-8">
          Prenez le contrôle de votre agenda. Réservez en quelques clics avec nos algorithmes intelligents et profitez de rappels personnalisés.
        </p>
        <a
          href="/book/demo"
          className="inline-flex items-center px-8 py-4 text-lg font-medium rounded-full bg-indigo-600 text-white shadow-lg transform transition hover:-translate-y-0.5 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
        >
          Commencer maintenant
        </a>
      </section>

      {/* Features Section */}
      <section className="py-16 px-6 bg-white dark:bg-gray-900">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8 text-left">
          <div className="flex flex-col items-start">
            <div className="p-3 rounded-md bg-indigo-100 dark:bg-indigo-900 mb-4">
              {/* Icon: calendar */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-8 h-8 text-indigo-600 dark:text-indigo-400"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 2v2m12-2v2M3.5 9.5h17m-17 9h17M4 7h16a2 2 0 012 2v11a2 2 0 01-2 2H4a2 2 0 01-2-2V9a2 2 0 012-2z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Réservation simplifiée</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Un processus de réservation fluide en trois étapes : choisissez votre coach, votre créneau puis confirmez. Notre IA vous suggère les meilleurs horaires.
            </p>
          </div>
          <div className="flex flex-col items-start">
            <div className="p-3 rounded-md bg-indigo-100 dark:bg-indigo-900 mb-4">
              {/* Icon: bell */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-8 h-8 text-indigo-600 dark:text-indigo-400"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Rappels intelligents</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Recevez des notifications automatiques avant vos rendez‑vous. Nos modèles adaptatifs ajustent le ton et le moment pour maximiser la présence.
            </p>
          </div>
          <div className="flex flex-col items-start">
            <div className="p-3 rounded-md bg-indigo-100 dark:bg-indigo-900 mb-4">
              {/* Icon: chart */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-8 h-8 text-indigo-600 dark:text-indigo-400"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M3 3v18h18M7 13l3 3 4-4 5 5"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Tableau de bord clair</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Suivez vos rendez‑vous, mesurez vos KPIs et gérez vos abonnements à partir d’un tableau de bord moderne et responsive.
            </p>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 px-6 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">Prêt à booster votre activité&nbsp;?</h2>
        <p className="max-w-2xl mx-auto text-lg md:text-xl mb-8">
          Rejoignez des coachs qui ont déjà multiplié leurs réservations grâce à AutoBooker&nbsp;AI. Essayez gratuitement et passez à la vitesse supérieure.
        </p>
        <a
          href="/book/demo"
          className="inline-flex items-center px-8 py-4 text-lg font-medium rounded-full bg-white text-indigo-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2"
        >
          Commencer votre essai
        </a>
      </section>
    </main>
  );
}