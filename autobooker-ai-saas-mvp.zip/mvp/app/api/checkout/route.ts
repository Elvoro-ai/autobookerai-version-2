import { NextRequest, NextResponse } from 'next/server';
import { createCheckoutSession, CheckoutPlan } from '@/lib/stripe';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { logger } from '@/lib/logger';

/**
 * Create a Stripe checkout session for the authenticated user.
 * Body: { plan: 'BASIC' | 'PRO' }
 */
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await req.json();
  const plan: CheckoutPlan = body.plan;
  if (!plan || !['BASIC', 'PRO'].includes(plan)) {
    return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });
  }
  try {
    logger.info('POST /api/checkout', { userId: session.user.id, plan });
    const checkoutSession = await createCheckoutSession({
      userId: session.user.id,
      plan,
      successUrl: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?checkout=success`,
      cancelUrl: `${process.env.NEXT_PUBLIC_APP_URL}/pricing?checkout=cancelled`,
    });
    return NextResponse.json({ url: checkoutSession.url });
  } catch (err: any) {
    logger.error('Error creating checkout session', err);
    return NextResponse.json({ error: err.message || 'Failed to create checkout session' }, { status: 500 });
  }
}