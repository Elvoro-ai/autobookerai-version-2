import { NextRequest, NextResponse } from 'next/server';
import { errorResponse } from '@/lib/error';
import { sendEmail } from '@/lib/email';
import { authOptions } from '@/lib/auth';
import { getServerSession } from 'next-auth/next';
import { logger } from '@/lib/logger';

/**
 * Send a notification email via Resend.
 * Expects JSON body { to, subject, html }.
 * Requires authentication (coach or admin).
 */

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return errorResponse('UNAUTHORIZED', 'You must be logged in to send notifications', 401);
  }
  const body = await req.json();
  const { to, subject, html } = body;
  if (!to || !subject || !html) {
    return errorResponse('MISSING_FIELDS', 'to, subject and html are required');
  }
  try {
    logger.info('POST /api/notify/send', { to, subject });
    await sendEmail({ to, subject, html });
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    logger.error('Error sending email', err);
    return errorResponse('EMAIL_FAILED', err?.message || 'Failed to send email', 500);
  }
}