import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { prisma } from '@/lib/prisma';
import Stripe from 'stripe';
import { logger } from '@/lib/logger';

/**
 * Handle Stripe webhook events. Currently supports checkout.session.completed.
 */
export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature') as string;
  const buf = await req.arrayBuffer();
  const body = Buffer.from(buf).toString('utf8');
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET || '');
  } catch (err: any) {
    logger.error('Stripe webhook signature verification failed', err);
    return new NextResponse(`Webhook Error: ${err.message}`, { status: 400 });
  }
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    const userId = session.metadata?.userId;
    const plan = session.metadata?.plan;
    if (userId && plan) {
      logger.info('Stripe checkout completed', { userId, plan });
      await prisma.subscription.create({
        data: {
          userId,
          stripeId: session.subscription as string,
          plan,
          status: 'active',
        },
      });
    }
  }
  return new NextResponse('OK', { status: 200 });
}