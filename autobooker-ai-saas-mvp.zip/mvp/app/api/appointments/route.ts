import { NextRequest, NextResponse } from 'next/server';
import { errorResponse } from '@/lib/error';
import { prisma } from '@/lib/prisma';
import { logger } from '@/lib/logger';
import { appointmentSchema } from '@/utils/validation';
import { authOptions } from '@/lib/auth';
import { getServerSession } from 'next-auth/next';

/**
 * Handle CRUD operations for appointments.
 *
 * GET: return a list of appointments for a given coach or the authenticated user.
 * POST: create a new appointment. Requires authentication and coach role.
 * PATCH: update an existing appointment's status. Requires authentication.
 */

export async function GET(req: NextRequest) {
  logger.info('GET /api/appointments', req.nextUrl.searchParams.toString());
  const coachId = req.nextUrl.searchParams.get('coachId');
  const session = await getServerSession(authOptions);
  // If no coachId provided, return appointments for the current user's coach (if any)
  const filterCoachId = coachId || (session?.user as any)?.coachId;
  if (!filterCoachId) {
    return errorResponse('MISSING_COACH_ID', 'coachId is required to fetch appointments');
  }
  const appointments = await prisma.appointment.findMany({
    where: { coachId: filterCoachId },
  });
  return NextResponse.json(appointments);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return errorResponse('UNAUTHORIZED', 'You must be logged in to create an appointment', 401);
  }
  // Only coaches can create appointments via this endpoint
  const coachId = (session.user as any)?.coachId;
  if (!coachId) {
    return errorResponse('NOT_COACH', 'Only coaches can create appointments', 403);
  }
  const body = await req.json();
  logger.info('POST /api/appointments', body);
  const parsed = appointmentSchema.safeParse(body);
  if (!parsed.success) {
    // Flatten zod errors into a human‑readable string
    const message = JSON.stringify(parsed.error.flatten().fieldErrors);
    return errorResponse('INVALID_REQUEST', message);
  }
  const { start, end, status, noShowRisk, clientEmail } = parsed.data;
  const appointment = await prisma.appointment.create({
    data: {
      coachId,
      start: new Date(start),
      end: new Date(end),
      status: status || 'SCHEDULED',
      noShowRisk: noShowRisk ?? null,
      clientEmail,
    },
  });
  return NextResponse.json(appointment);
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return errorResponse('UNAUTHORIZED', 'You must be logged in to update an appointment', 401);
  }
  const id = req.nextUrl.searchParams.get('id');
  if (!id) {
    return errorResponse('MISSING_ID', 'Appointment id is required');
  }
  const body = await req.json();
  logger.info('PATCH /api/appointments', { id, body });
  const status = body.status as string | undefined;
  // Only allow updating status for now
  if (!status) {
    return errorResponse('MISSING_STATUS', 'Status is required to update an appointment');
  }
  const updated = await prisma.appointment.update({
    where: { id },
    data: { status },
  });
  return NextResponse.json(updated);
}