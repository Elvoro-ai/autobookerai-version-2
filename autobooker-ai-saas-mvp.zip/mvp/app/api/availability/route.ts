import { NextRequest, NextResponse } from 'next/server';
import { errorResponse } from '@/lib/error';
import { prisma } from '@/lib/prisma';
import { logger } from '@/lib/logger';
import { availabilitySchema } from '@/utils/validation';
import { authOptions } from '@/lib/auth';
import { getServerSession } from 'next-auth/next';

export async function GET(req: NextRequest) {
  logger.info('GET /api/availability', req.nextUrl.searchParams.toString());
  const coachId = req.nextUrl.searchParams.get('coachId');
  if (!coachId) {
    return errorResponse('MISSING_COACH_ID', 'coachId is required to fetch availability');
  }
  const avail = await prisma.availability.findMany({ where: { coachId } });
  return NextResponse.json(avail);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return errorResponse('UNAUTHORIZED', 'You must be logged in to create availability', 401);
  }
  const body = await req.json();
  logger.info('POST /api/availability', body);
  const parsed = availabilitySchema.safeParse(body);
  if (!parsed.success) {
    const message = JSON.stringify(parsed.error.flatten().fieldErrors);
    return errorResponse('INVALID_REQUEST', message);
  }
  // assume user has coachId field
  const coachId = session.user?.coachId;
  if (!coachId) {
    return errorResponse('NOT_COACH', 'Only coaches can create availability', 403);
  }
  const availability = await prisma.availability.create({
    data: {
      coachId,
      start: new Date(parsed.data.start),
      end: new Date(parsed.data.end),
    },
  });
  return NextResponse.json(availability);
}