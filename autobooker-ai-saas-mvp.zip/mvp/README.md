# AutoBooker AI

AutoBooker AI est un SaaS de gestion de rendez‑vous optimisé par l’IA. Cette application permet aux coachs de proposer leurs disponibilités, aux clients de réserver des créneaux et de recevoir des rappels automatisés. La plateforme est construite avec **Next.js App Router** et **TypeScript**, utilise **Prisma** et **PostgreSQL** pour la base de données, **Auth.js** pour l’authentification via magic link, **Resend** pour l’envoi d’e‑mails, **Upstash** pour la file de tâches et le cache, et **Stripe** pour la monétisation.

## Fonctionnalités principales

- Pages publiques : landing page (`/`), réservation d’un coach (`/book/[coach]`), pages légales (`/legal`, `/privacy`, `/terms`, `/cookies`).
- Tableau de bord (`/dashboard`) pour consulter ses rendez‑vous et métriques.
- Espace administrateur (`/admin`) pour gérer les coachs et les rôles.
- API REST :
  - `GET/POST /api/availability` : lire/écrire les disponibilités.
  - `GET/POST/PATCH /api/appointments` : gérer les rendez‑vous (création, modification).
  - `POST /api/notify/send` : envoyer un e‑mail de notification via Resend.
  - `POST /api/checkout` : créer une session Stripe Checkout pour s’abonner.
  - `POST /api/stripe/webhook` : recevoir les évènements Stripe (paiements).
  - `POST /api/cron/reminders?key=…` : endpoint protégé pour déclencher les rappels et relances.

Toutes les routes API utilisent désormais une structure d’erreur unifiée grâce à `lib/error.ts`. Lorsqu’une erreur se produit, la réponse est toujours de la forme :

```json
{
  "error": {
    "code": "STRING_CODE",
    "message": "Human readable message"
  }
}
```

Quelques codes courants :

| Code                | Signification                                                       |
|---------------------|---------------------------------------------------------------------|
| `MISSING_COACH_ID`  | Aucun identifiant de coach fourni dans la requête                   |
| `UNAUTHORIZED`      | L’utilisateur n’est pas authentifié                                 |
| `NOT_COACH`         | L’utilisateur authentifié n’est pas un coach                        |
| `INVALID_REQUEST`   | Le corps de la requête ne respecte pas le schéma Zod                |
| `MISSING_STATUS`    | Le champ `status` est manquant lors de la mise à jour d’un rendez‑vous |
| `EMAIL_FAILED`      | L’envoi de l’e‑mail a échoué                                        |

Consultez `lib/error.ts` pour plus de détails et ajoutez vos propres codes selon les cas métier.
- Fichier Prisma `schema.prisma` définissant les modèles `User`, `Coach`, `Availability`, `Appointment` et `Subscription` avec leurs relations et énumérations.
- Module `lib/ai.ts` avec les fonctions IA : `suggestBestSlots`, `smartReminderCopy` et `noShowRisk` (à compléter avec un appel LLM et un fallback heuristique).
- Intégration Stripe via `lib/stripe.ts` et `app/api/checkout`.
- Authentification par e‑mail via `lib/auth.ts` et **Auth.js**.
- Middleware de rate‑limiting simple dans `middleware/rate-limit.ts`.
- Validation des entrées avec **Zod** (`utils/validation.ts`).

## Pré‑requis

- Node.js >= 18
- Une base PostgreSQL (Neon, Railway, Render ou autre)
- Un compte Resend (pour l’envoi d’e‑mails)
- Un compte Upstash (Redis et cron)
- Un compte OpenAI ou Mistral (pour les fonctionnalités IA)
- Un compte Stripe (pour la facturation)

## Configuration

1. Dupliquez le fichier `.env.example` en `.env` et remplissez toutes les variables :

   ```bash
   cp .env.example .env
   # éditez .env avec vos clés (DATABASE_URL, NEXTAUTH_SECRET, RESEND_API_KEY, etc.)
   ```

   Les variables optionnelles pour Calendly, Twilio et Gmail sont commentées dans `.env.example` ; remplissez‑les uniquement si vous utilisez ces intégrations.

2. Installez les dépendances :

   ```bash
   npm install
   ```

3. Générez le client Prisma, exécutez les migrations et vérifiez vos variables d’environnement en une seule commande :

   ```bash
   npm run bootstrap
   ```

4. Démarrez le serveur de développement :

   ```bash
   npm run dev
   ```

L’application sera disponible sur `http://localhost:3000`.

## Tests

Quelques tests cURL pour vérifier les principales API :

1. Récupérer les disponibilités :

   ```bash
   curl -X GET "http://localhost:3000/api/availability?coachId=<idCoach>"
   ```

2. Créer une disponibilité (requiert un coach authentifié) :

   ```bash
   curl -X POST "http://localhost:3000/api/availability" \
     -H "Content-Type: application/json" \
     -d '{"start":"2025-01-01T09:00:00Z","end":"2025-01-01T10:00:00Z"}'
   ```

3. Créer un rendez‑vous (requiert un coach authentifié) :

   ```bash
   curl -X POST "http://localhost:3000/api/appointments" \
     -H "Content-Type: application/json" \
     -d '{"coachId":"<idCoach>","start":"2025-01-01T09:00:00Z","end":"2025-01-01T09:30:00Z","clientEmail":"client@example.com"}'
   ```

4. Envoyer un e‑mail de notification :

   ```bash
   curl -X POST "http://localhost:3000/api/notify/send" \
     -H "Content-Type: application/json" \
     -d '{"to":"client@example.com","subject":"Test","html":"<strong>Hello</strong>"}'
   ```

Chaque requête en erreur renverra l’objet JSON normalisé décrit plus haut.

## Déploiement sur Vercel

1. Créez un nouveau projet sur Vercel en reliant ce dépôt GitHub.
2. Ajoutez toutes les variables d’environnement du fichier `.env.example` via l’interface Vercel (onglet **Settings → Environment Variables**). Assurez‑vous d’inclure les secrets Stripe, Resend, Upstash, OpenAI/Mistral et NextAuth.
3. Configurez le webhook Stripe dans votre tableau de bord Stripe en utilisant l’URL : `https://<your-vercel-domain>/api/stripe/webhook` et la clé secrète correspondante (`STRIPE_WEBHOOK_SECRET`).
4. Configurez une tâche Upstash Cron pour appeler `https://<your-vercel-domain>/api/cron/reminders?key=<CRON_SECRET_KEY>` à l’heure souhaitée (ex. 09:00 UTC chaque jour pour les rappels).

5. Mettez en place la CI : un workflow GitHub (`.github/workflows/lighthouse.yml`) exécutera Lighthouse sur vos pages publiques à chaque pull request. Assurez‑vous de définir le secret `LHCI_GITHUB_APP_TOKEN` dans votre dépôt pour publier les rapports.
5. Déployez la branche principale (Vercel détectera automatiquement le framework Next.js et construira l’application). Vérifiez les logs de déploiement pour vous assurer que Prisma se connecte correctement à votre base de données.

## Conformité RGPD et sécurité

Cette application stocke les données dans l’UE via votre fournisseur PostgreSQL. Les secrets sont chargés depuis les variables d’environnement. Un middleware de rate‑limit simple empêche les abus. N’oubliez pas d’ajouter vos mentions légales, votre politique de confidentialité, vos conditions générales et votre gestion des cookies dans les pages correspondantes. Prévoyez également une procédure d’exportation et de suppression de compte pour les utilisateurs.

Une table `Consent` a été ajoutée dans le schéma Prisma pour journaliser les consentements (e‑mail/SMS) des utilisateurs. Cette table permet de prouver le consentement en cas de contrôle. Des endpoints d’export et de suppression peuvent être ajoutés dans `app/api` pour respecter pleinement le RGPD (à implémenter en fonction de vos besoins).

### Procédure d’incident

En cas d’erreur serveur (code 5xx), l’erreur est automatiquement envoyée à **Sentry** (via `@sentry/nextjs`). Consultez votre tableau de bord Sentry pour suivre les incidents. Les logs côté serveur sont également disponibles via `lib/logger.ts`. Lorsqu’une anomalie est détectée (score Lighthouse < 90 ou tests Cypress qui échouent), corrigez le code et ajoutez un commentaire dans le fichier `CHANGELOG.md` décrivant la cause et la résolution.

---

Ceci est un squelette de projet qui peut être étendu et affiné. Les fonctions IA dans `lib/ai.ts` doivent être implémentées avec un appel à OpenAI ou Mistral (via API HTTP) et un cache Redis (Upstash). Le design peut être amélioré avec **Tailwind CSS**, **shadcn/ui** et **Radix** pour obtenir un rendu premium conforme au cahier des charges.