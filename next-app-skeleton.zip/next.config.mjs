/** @type {import('next').NextConfig} */
const nextConfig = {
  // Nothing fancy needed; this is only to ensure Next builds.
};

export default nextConfig;
