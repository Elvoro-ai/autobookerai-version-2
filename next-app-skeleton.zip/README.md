# Minimal `app` folder for Next.js on Netlify

This drops a working `app/` directory into your project so `npm run build` stops failing with
"Couldn't find any `pages` or `app` directory". It also includes a `netlify.toml` tuned for Next.js.

## What to do
1. Unzip this at the root of your Next.js project (same folder as your `package.json`).
2. Ensure your `package.json` has:
   ```json
   {
     "scripts": {
       "build": "next build",
       "dev": "next dev",
       "start": "next start"
     }
   }
   ```
3. In Netlify:
   - **Build command**: `npm run build`
   - **Publish directory**: `.next`
   - **Node version**: set to 20 (in Netlify UI or via `netlify.toml` provided here).
   - If you're in a monorepo, set **Base directory** to the folder that contains this `app/` and `package.json`.
4. Commit & push, trigger a new deploy.

## Notes
- If you already use the `pages/` router, you can ignore `app/` and create a `pages/index.tsx` instead.
- If your source lives in a subfolder (e.g. `apps/web`), set Netlify's **Base directory** to `apps/web`.
