export default function HomePage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>It works 🎉</h1>
      <p>
        This is a minimal <code>app</code> directory so Next.js can build on Netlify.
      </p>
      <p>
        Edit <code>app/page.tsx</code> and start building your product.
      </p>
    </main>
  );
}
