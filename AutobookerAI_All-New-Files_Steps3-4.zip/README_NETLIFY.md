# Déploiement sur Netlify (AutoBooker AI)

## TL;DR
1. **Importer le repo sur Netlify** (New site from Git).
2. Dans “Site settings → Build & deploy → Build settings” laissez vide, car `netlify.toml` gère tout :  
   - base: `autobooker-ai`  
   - command: `npm ci && npm run build`  
   - publish: `autobooker-ai/.next`
3. **Variables d’environnement** (Site settings → Environment variables) : recopiez celles de `.env.example`.
4. **Node** : Netlify détecte `/.nvmrc` → Node 20.
5. **Déployer**. Le plugin `@netlify/plugin-nextjs` s’occupe du SSR/ISR.
6. Local: `npm i -g netlify-cli` puis `netlify dev` à la racine du repo.

## Vérifications
- Build OK, pages SSR/ISR répondent 200, `/api/*` OK.
- Aucun warning bloquant, images optimisées, 404/500 personnalisées.
- Sécurité headers actifs (CSP à durcir selon vos domaines réels).

## Dépannage
- Erreur “no pages/app directory” → Vérifiez que la **base** est bien `autobooker-ai` (dans `netlify.toml`).
- Timeout SSR → regardez les logs “.netlify/functions/*”.

