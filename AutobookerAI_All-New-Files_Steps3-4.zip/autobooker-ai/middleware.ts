import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';
import { rateLimit } from './lib/security/rate-limit';
import { cspHeader } from './lib/security/csp';

export function middleware(req: NextRequest) {
  // Rate limit all API routes and auth endpoints
  if (req.nextUrl.pathname.startsWith('/api')) {
    const limited = rateLimit(req);
    if (limited) return limited;
  }

  // Security headers (CSP, frame, etc.) for all routes
  const res = NextResponse.next();
  res.headers.set('Content-Security-Policy', cspHeader());
  res.headers.set('X-Frame-Options', 'DENY');
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  return res;
}

// Run on all routes (let Next handle static assets efficiently)
export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml).*)'],
};
