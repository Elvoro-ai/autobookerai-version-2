export const dynamic = 'force-dynamic';
export async function GET(){
  // TODO: add DB ping, queue status, etc.
  return new Response('READY');
}
