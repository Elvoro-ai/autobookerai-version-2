import { NextRequest, NextResponse } from 'next/server';
import { contactSchema } from '@/lib/validation/contact';
import { assertCsrf, getOrSetCsrfCookie } from '@/lib/security/csrf';

export async function GET() {
  // Provide CSRF token to clients via header for subsequent POST
  const token = getOrSetCsrfCookie();
  return NextResponse.json({ ok: true }, { headers: { 'x-csrf-token': token }});
}

export async function POST(req: NextRequest) {
  try {
    assertCsrf();
    const json = await req.json();
    const data = contactSchema.parse(json);
    // TODO: enqueue or send email via provider abstraction
    return NextResponse.json({ ok: true, received: data }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Invalid payload' }, { status: 400 });
  }
}
