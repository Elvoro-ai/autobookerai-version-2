export default function NotFound() {
  return (
    <main className="p-8 text-center">
      <h1 className="text-3xl font-bold mb-2">Page introuvable</h1>
      <p className="text-gray-600">Désolé, cette page n’existe pas.</p>
    </main>
  );
}
