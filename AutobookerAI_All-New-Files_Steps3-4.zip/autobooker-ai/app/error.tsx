'use client';

export default function GlobalError({ error }: { error: Error & { digest?: string } }) {
  return (
    <html>
      <body className="p-8 text-center">
        <h1 className="text-3xl font-bold mb-2">Oups… une erreur est survenue</h1>
        <p className="text-gray-600">Réessayez plus tard. {process.env.NODE_ENV !== 'production' ? error.message : ''}</p>
      </body>
    </html>
  );
}
