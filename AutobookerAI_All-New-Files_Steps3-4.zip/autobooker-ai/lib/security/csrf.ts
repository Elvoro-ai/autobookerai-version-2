import { cookies, headers } from 'next/headers';
import crypto from 'crypto';

const CSRF_COOKIE = 'csrf-token';

function hmac(secret: string, value: string) {
  return crypto.createHmac('sha256', secret).update(value).digest('hex');
}

export function getOrSetCsrfCookie() {
  const jar = cookies();
  const existing = jar.get(CSRF_COOKIE)?.value;
  const secret = process.env.CSRF_SECRET || 'dev-secret-change-me';
  if (existing) return existing + '.' + hmac(secret, existing);
  const raw = crypto.randomBytes(16).toString('hex');
  const token = raw + '.' + hmac(secret, raw);
  jar.set(CSRF_COOKIE, raw, { httpOnly: true, sameSite: 'lax', secure: true, path: '/' });
  return token;
}

// Validate token present in header 'x-csrf-token' signed by secret and matching cookie value.
export function assertCsrf() {
  const hdrs = headers();
  const provided = hdrs.get('x-csrf-token');
  if (!provided) throw new Error('Missing CSRF token');
  const [raw, sig] = provided.split('.');
  const secret = process.env.CSRF_SECRET || 'dev-secret-change-me';
  const expected = hmac(secret, raw);
  const jar = cookies().get(CSRF_COOKIE)?.value;
  if (!raw || !sig || expected !== sig || jar !== raw) {
    throw new Error('Invalid CSRF token');
  }
}
