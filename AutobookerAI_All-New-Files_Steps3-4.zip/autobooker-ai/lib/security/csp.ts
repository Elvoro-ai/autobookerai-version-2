// Build a CSP string. Adjust directives to your real domains (fonts, images, analytics).
export function cspHeader() {
  const directives = {
    "default-src": ["'self'"],
    "img-src": ["'self'", "data:", "blob:", "https:"],
    "script-src": ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https:"],
    "style-src": ["'self'", "'unsafe-inline'", "https:"],
    "font-src": ["'self'", "data:", "https:"],
    "connect-src": ["'self'", "https:", "wss:"],
    "frame-ancestors": ["'none'"],
  };
  const toStr = (k: string, v: string[]) => `${k} ${v.join(' ')}`;
  return Object.entries(directives).map(([k, v]) => toStr(k, v as string[])).join('; ');
}
