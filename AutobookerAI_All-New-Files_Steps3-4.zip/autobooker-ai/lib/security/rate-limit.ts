import { NextRequest, NextResponse } from 'next/server';

// Simple in-memory sliding window rate limiter (best-effort across a single instance)
// For multi-instance, plug an external store (Upstash/Redis).

type Bucket = { tokens: number; updatedAt: number };
const BUCKETS = new Map<string, Bucket>();

function now() { return Date.now(); }

export function rateLimit(req: NextRequest, opts?: { id?: string; tokensPerMin?: number }) {
  const key =
    opts?.id ||
    `${req.ip || '0.0.0.0'}:${req.headers.get('x-forwarded-for') || ''}:${req.nextUrl.pathname}`;
  const limit = Number(process.env.RATE_LIMIT_TOKENS_PER_MIN || 60);
  const tokensPerMin = opts?.tokensPerMin ?? limit;
  const perMs = 60_000;
  const t = now();
  const b = BUCKETS.get(key) || { tokens: tokensPerMin, updatedAt: t };
  const elapsed = t - b.updatedAt;
  const refill = (elapsed / perMs) * tokensPerMin;
  b.tokens = Math.min(tokensPerMin, b.tokens + refill);
  b.updatedAt = t;

  if (b.tokens < 1) {
    BUCKETS.set(key, b);
    return NextResponse.json({ error: 'Too Many Requests' }, { status: 429, headers: {
      'Retry-After': '60'
    }});
  }

  b.tokens -= 1;
  BUCKETS.set(key, b);
  return null;
}
