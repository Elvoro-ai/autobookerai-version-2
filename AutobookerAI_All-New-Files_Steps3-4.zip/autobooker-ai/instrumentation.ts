export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    // Lazy load to avoid bundling for edge
    const { diag, DiagConsoleLogger, DiagLogLevel } = await import('@opentelemetry/api');
    diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.ERROR);
    // Here you could initialize an OTLP exporter/SDK. Omitted for brevity.
  }
}
