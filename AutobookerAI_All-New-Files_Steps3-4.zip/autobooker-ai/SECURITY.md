# Security Hardening

- **CSP** activée via `middleware.ts` (durcir les domaines réels).
- **Rate limit** (in-memory) sur `/api/*`. Pour production multi-instance, utiliser Redis (Upstash).
- **CSRF**:
  - GET `/api/contact` renvoie un header `x-csrf-token` signé + cookie `csrf-token` (httpOnly).
  - POST `/api/contact` exige le header `x-csrf-token` qui doit matcher le cookie.
- **Headers**: HSTS, X-Frame-Options, etc. (voir `netlify.toml` + `middleware.ts`).

## À configurer
- Variables d'env (`.env.example`), secrets non commités.
- Auth (NextAuth ou Clerk) avec cookies sécurisés (SameSite=Lax, Secure).
