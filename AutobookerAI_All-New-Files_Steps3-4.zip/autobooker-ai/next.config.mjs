/** @type {import('next').NextConfig} */
const nextConfig = {
  images: { domains: ['images.unsplash.com','res.cloudinary.com'] },

  reactStrictMode: true,
  };

export default nextConfig;
export const instrumentation = './instrumentation.ts';

