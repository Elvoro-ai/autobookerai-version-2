# Observability

- **Sentry**: config via `sentry.*.config.ts`, DSN dans l'env.
- **OpenTelemetry**: `instrumentation.ts` active le logger et prépare l'init SDK.
- **Healthchecks**: `/api/live` et `/api/ready` (ajouter ping DB/queues).
- **Logs**: préférez `console.log(JSON.stringify({ ... }))` pour logs structurés.
