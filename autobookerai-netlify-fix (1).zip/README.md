# Netlify Fix — AutoBookerAI (Next.js)

Ce pack corrige l’erreur _"Couldn't find any `pages` or `app` directory"_ en ajoutant
une structure **Next.js** minimale compatible Netlify.

## Contenu
- `pages/index.js` : page d’accueil minimale (file‑system routing OK)
- `package.json` : scripts `dev|build|start`, versions (Next 14.2.5, React 18.3.1)
- `next.config.js` : strict mode (modifiable)
- `netlify.toml` : plugin **@netlify/plugin-nextjs**, build `npm run build`, publish `.next`
- `.gitignore` : exclusions standards

## Recommandation de workflow (sécurisée)
1. **Créez une branche** :
   ```bash
   git checkout -b fix/netlify-next-pages
   ```
2. **Ajoutez ces fichiers** dans le repo à la racine (ou remplacez si existants), puis :
   ```bash
   git add .
   git commit -m "fix(netlify): add pages/ scaffold + netlify.toml + next config"
   git push -u origin fix/netlify-next-pages
   ```
3. **Ouvrez une Pull Request** vers `main`.
4. **Vérifiez le Netlify Deploy Preview** sur la PR (la page d’accueil doit s’afficher).
5. **Fusionnez dans `main`** une fois le preview vert.

> Si vous préférez aller vite, vous pouvez *committer directement sur `main`*.
> **Meilleure pratique** : branche + PR pour profiter des *Deploy Previews* Netlify.  

## Paramètres Netlify à vérifier
- Build command : `npm run build`
- Base directory : racine du repo
- Publish directory : `.next` (laisse Netlify gérer via le plugin)
- Node version : 18 ou 20 (ou 22 compatible). Vous pouvez fixer `NODE_VERSION=20` dans les variables Netlify.

## Tests locaux
```bash
npm install
npm run build
npm start
# Ouvrir http://localhost:3000
```

---
_Généré le 2025-10-21 20:43 _
