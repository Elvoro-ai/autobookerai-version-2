export default function HomePage() {
  return (
    <main style={{display:'grid',placeItems:'center',minHeight:'100vh',fontFamily:'system-ui, Arial, sans-serif'}}>
      <section style={{textAlign:'center'}}>
        <h1 style={{marginBottom:8}}>AutoBookerAI</h1>
        <p>Déploiement Netlify OK ✅ — structure Next.js minimale avec <code>pages/</code>.</p>
      </section>
    </main>
  );
}
