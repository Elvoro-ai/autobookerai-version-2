
# VERIFY after pushing

1) **Netlify > Site settings > Build & deploy**
   - Base directory: `autobooker-ai`
   - Build command: `npm run build`
   - Publish directory: `.next`
   - Node version: `20.19.5` (either from `netlify.toml` or the UI)

2) **Repo**
   - `package.json` no longer references `@auth/core@1.5.0`
   - A **new** lockfile is committed (e.g., `package-lock.json`).
   - `@netlify/plugin-nextjs` is present (added via `netlify.toml`).

3) **Project structure**
   - Ensure you have either `app/` **or** `pages/` at the app root.
   - Example minimal file to avoid the “no app/pages” error:
     - `app/page.tsx` with a simple component exporting default.

4) **Environment variables**
   - Add your secrets in **Netlify > Site settings > Environment variables** (e.g., AUTH_SECRET, NEXTAUTH_URL, DATABASE_URL, etc.).
