
# Netlify Deploy — Fix Kit (Autobooker AI / Next.js)

This kit fixes the **ETARGET @auth/core@1.5.0** error and solidifies your Netlify build.

---

## What’s inside

- `apply-netlify-fixes.sh` — one-click script to patch your `package.json`, clean the lockfile, and reinstall.
- `netlify.toml` — safe defaults for a Next.js app in a subfolder (`autobooker-ai`) on Netlify.
- `.nvmrc` — pins Node.js to 20.19.5 (matches your Netlify build logs).
- `.npmrc` — ensures the standard npm registry is used and avoids odd peer-deps stalls.
- `VERIFY.md` — quick checklist to confirm everything is green.
- `PATCH_NOTES.md` — exactly what changes are made and why.

> **Important:** Run this from the **root of your repo** (the one that contains the `autobooker-ai` folder).
> If your app is **not** in `autobooker-ai`, edit `netlify.toml` (the `base` value) accordingly.

---

## TL;DR – Commands to run (copy/paste)

```bash
# From the repo root
bash ./apply-netlify-fixes.sh

# Commit the changes
git add -A
git commit -m "fix(netlify): correct @auth/core version + stable Node/npm config"
git push origin main  # or your branch

# Re-deploy on Netlify
```

If your Netlify site is already connected to the repo, a push will trigger a fresh build.

---

## Why your build failed

Your Netlify logs show:

- `npm error code ETARGET`
- `No matching version found for @auth/core@1.5.0`

That means your `package.json` (or a transitive dep) pinned `@auth/core` to a version that **does not exist on npm**.  
Auth.js (formerly NextAuth) uses `@auth/core` versions in the `0.x` range. Pinning to `1.5.0` will always fail.

**Fix:** Set `@auth/core` to a valid **0.x** version (we use `^0.32.2`), reinstall with a fresh lockfile, and commit both the `package.json` and the new lockfile.

---

## Bonus hardening included

- Pin Node to 20.19.5 (the exact version your logs show Netlify installed).
- Ensure npm uses the public registry explicitly.
- Provide a `netlify.toml` with good defaults for a Next.js app living in a subdirectory (`autobooker-ai`).

