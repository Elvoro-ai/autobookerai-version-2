
# PATCH NOTES — What changed and why

1) **@auth/core version**
   - Replaced any `@auth/core@1.5.0` with `@auth/core:^0.32.2`.
   - Reason: version `1.5.0` does **not** exist on npm, which caused `ETARGET` on Netlify.

2) **Lockfile refresh**
   - Deleted old lockfile and `node_modules`, then ran a fresh install so the lockfile matches the fixed versions.
   - Reason: Netlify uses `npm ci` by default; an out-of-sync lockfile can reintroduce the bad version.

3) **Node & npm stability**
   - Added `.nvmrc` with Node `20.19.5` (matches your Netlify log).
   - Added `.npmrc` with standard registry and minor stability flags.

4) **Netlify settings**
   - Provided `netlify.toml` to set base directory `autobooker-ai`, `npm run build`, and publish `.next`.
   - Added Netlify Next.js Runtime plugin.

5) **Safety checks**
   - `VERIFY.md` lists everything to confirm post-push.
