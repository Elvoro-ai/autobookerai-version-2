#!/usr/bin/env bash
set -euo pipefail

# Detect repo root (current dir)
ROOT_DIR="$(pwd)"

echo "==> Applying Netlify/Next.js fixes in: ${ROOT_DIR}"

# 1) Choose the app subfolder (edit if your app path differs)
APP_DIR="autobooker-ai"
if [ ! -d "$APP_DIR" ]; then
  echo "!! WARNING: '${APP_DIR}' folder not found. If your Next.js app is elsewhere, edit APP_DIR inside this script."
fi

# 2) Ensure Node 20.19.5 via .nvmrc
echo "20.19.5" > "${ROOT_DIR}/.nvmrc"
echo "==> Wrote .nvmrc (Node 20.19.5)"

# 3) Ensure npm uses the public registry & sane defaults
cat > "${ROOT_DIR}/.npmrc" <<'NPMRC'
registry=https://registry.npmjs.org/
fund=false
audit=false
NPMRC
echo "==> Wrote .npmrc"

# 4) Patch package.json for @auth/core (in app dir if present, otherwise root)
TARGET_PKG_JSON="package.json"
if [ -f "${ROOT_DIR}/${APP_DIR}/package.json" ]; then
  TARGET_PKG_JSON="${ROOT_DIR}/${APP_DIR}/package.json"
elif [ -f "${ROOT_DIR}/package.json" ]; then
  TARGET_PKG_JSON="${ROOT_DIR}/package.json"
else
  echo "!! ERROR: No package.json found at repo root or in ${APP_DIR}/"
  exit 1
fi

echo "==> Patching ${TARGET_PKG_JSON} to use @auth/core ^0.32.2 (and remove bad 1.5.0)"

# Use jq if available; otherwise fallback to sed (simple string replace)
if command -v jq >/dev/null 2>&1; then
  TMP_PKG="$(mktemp)"
  jq '
    .dependencies |=
      ( . // {} 
        | if has("@auth/core") then .["@auth/core"]="^0.32.2" else . end
      )
    |
    .devDependencies |=
      ( . // {} 
        | if has("@auth/core") then .["@auth/core"]="^0.32.2" else . end
      )
  ' "${TARGET_PKG_JSON}" > "${TMP_PKG}"
  mv "${TMP_PKG}" "${TARGET_PKG_JSON}"
else
  # sed fallback (best-effort)
  sed -i.bak 's/"@auth\/core":[^,}]\+/"@auth\/core":"^0.32.2"/g' "${TARGET_PKG_JSON}" || true
fi

# 5) Clean lockfiles and node_modules in the chosen app dir
PKG_DIR="$(dirname "${TARGET_PKG_JSON}")"
cd "${PKG_DIR}"

echo "==> Removing lockfile & node_modules to force a clean, reproducible install"
rm -f package-lock.json pnpm-lock.yaml yarn.lock
rm -rf node_modules

# 6) Fresh install
if [ -f "package.json" ]; then
  if [ -f "pnpm-lock.yaml" ] || grep -q "\"packageManager\": \"pnpm" package.json 2>/dev/null; then
    echo "==> Detected pnpm. Installing..."
    pnpm install --no-frozen-lockfile
  elif [ -f "yarn.lock" ] || grep -q "\"packageManager\": \"yarn" package.json 2>/dev/null; then
    echo "==> Detected yarn. Installing..."
    yarn install --check-files
  else
    echo "==> Using npm. Installing with npm install (not npm ci to regenerate lockfile)"
    npm install
  fi
else
  echo "!! ERROR: No package.json found at ${PKG_DIR}"
  exit 1
fi

echo "==> Done. Verify build locally:"
echo "npm run build"
