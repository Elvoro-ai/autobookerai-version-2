export default function HomePage() {
  return (
    <main style={{padding: "2rem"}}>
      <h1>It works 🎉</h1>
      <p>
        This minimal <code>app</code> directory unblocks the Netlify Next.js build.
      </p>
      <p>
        You can now replace this with your real routes and components.
      </p>
    </main>
  );
}
