export const metadata = {
  title: "Autobooker AI",
  description: "Minimal Next.js app scaffold to satisfy Netlify build.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial"}}>
        {children}
      </body>
    </html>
  );
}
