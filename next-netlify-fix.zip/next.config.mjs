// Minimal Next.js config; keep or merge into your existing one if present.
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // If your repo lives in a subdirectory, configure 'output' or basePath as needed.
  // output: 'standalone',
};
export default nextConfig;
