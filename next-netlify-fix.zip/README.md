# Netlify x Next.js quick fix

This adds a minimal **`app/`** directory so Netlify's Next.js build stops failing with:
> "Couldn't find any `pages` or `app` directory. Please create one under the project root."

## What to do

1) Drop the `app/` folder (and `netlify.toml` if you need it) into the **root of the repo that Netlify builds**.
   - If your Next.js app lives in a subfolder (e.g. `apps/web`), either:
     - Move these files into that folder **and** set Netlify's "Base directory" to that folder in Site settings → Build & deploy, **OR**
     - Keep them at the repo root and set `base = "apps/web"` inside `netlify.toml`.
2) Ensure your `package.json` has:
   ```json
   {
     "scripts": {
       "build": "next build",
       "dev": "next dev",
       "start": "next start"
     }
   }
   ```
3) Trigger a new deploy on Netlify.

## Notes
- If you already have a `pages/` or `app/` directory elsewhere, point Netlify to it via Site settings (Base directory) or `netlify.toml`'s `base` key.
- `NODE_VERSION` is pinned to 20 here, which is broadly compatible with most Next.js versions. If your project requires a different Node, adjust it.
- The `@netlify/plugin-nextjs` plugin is enabled to ensure proper routing and ISR/SSR support on Netlify.

Once your real routes are in place, feel free to delete or replace the placeholder content in `app/page.jsx`.
