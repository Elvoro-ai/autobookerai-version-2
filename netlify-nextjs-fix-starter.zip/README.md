# Netlify + Next.js (App Router) — Minimal Fix Starter

This starter ensures your repository has a **required** `app/` (or `pages/`) directory
so the Netlify build won't fail with: "couldn't find any `pages` or `app` directory".

## What’s included
- `app/` with `page.tsx` and `layout.tsx`
- `next.config.js` (basic)
- `package.json` with `build`, `dev`, `start` scripts
- `netlify.toml` with the official Next.js plugin
- `.nvmrc` pinning Node 20 (compatible with Next.js + Netlify)

## How to use in your repo
1) Download this ZIP and **copy its files to your repository root** (merge with existing files).
2) Commit and push:
   ```bash
   git add .
   git commit -m "fix: add Next.js app dir + Netlify config"
   git push origin main
   ```
3) In Netlify:
   - **Build command**: `npm run build`
   - **Publish directory**: `.next`
   - Ensure **Node** is 18+ (UI or via `.nvmrc`).

### Monorepo / subfolder?
If your Next.js app lives in a subfolder (e.g., `apps/web`), set the **Base directory** to that folder in Netlify
Site settings → Build & deploy → Build settings. Next.js **does not support** a custom `pagesDir` in `next.config.js`.
You must keep the folder name **`app/`** or **`pages/`** inside the base directory.

## Notes
- Next.js does **not** have a `pagesDir` config option. The directories must be named `pages/` (Pages Router) or `app/` (App Router).
- If you were using the legacy Pages Router, you can rename `app/` to `pages/` and keep the rest the same.
