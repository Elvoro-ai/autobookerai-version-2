export default function Page() {
  return (
    <main style={{ padding: 24 }}>
      <h1>✅ Next.js on Netlify — working</h1>
      <p>If you see this, your <code>app/</code> directory is correctly detected by Next.js during the Netlify build.</p>
      <p>Edit <code>app/page.tsx</code> and redeploy.</p>
    </main>
  );
}
