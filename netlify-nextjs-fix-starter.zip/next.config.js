// @ts-check
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Ensure the default App Router is enabled via the /app directory.
  poweredByHeader: false,
  reactStrictMode: true,
};

module.exports = nextConfig;
